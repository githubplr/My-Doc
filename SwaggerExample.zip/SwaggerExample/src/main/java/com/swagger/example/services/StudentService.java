package com.swagger.example.services;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;

import com.swagger.example.dao.StudentDao;

@Service     
public class StudentService {
	 static Map<Integer, StudentDao> mymap; 
	 
	 private final static Logger logger= LoggerFactory.getLogger(StudentService.class);
	 //creating object of logger
	
	//StudentDao dao=new StudentDao(studentId, studentName, studentPhone);
	public static Map<Integer, StudentDao> StudentDetails() {  //not for service ---use for hardcoding daa
		
		logger.info("--StudentDetails()--{}");
	mymap=	new ConcurrentHashMap<Integer, StudentDao>();
		mymap.put(1,new StudentDao(100, "jon", 111));
		mymap.put(2,new StudentDao(200, "jack", 222));
		mymap.put(3,new StudentDao(300, "anny", 333));
		mymap.put(4,new StudentDao(400, "monty", 444));
		mymap.put(5,new StudentDao(500, "anna", 555));
		
		logger.info("--StudentDetails()-- DATA  {}"+mymap);
		return mymap;
    }

	public  Map<Integer, StudentDao> getStudentDetails() {
		logger.info("--getStudentDetails()-- DATA  {}");
		Map<Integer, StudentDao> studentData= StudentDetails();
		logger.info("--getStudentDetails()-- RESPONSE  {}"+studentData);
	return studentData;
	}
	
    public  List<Entry<Integer, StudentDao>> getStudentDetailsById(int id) {
    	logger.info("--getStudentDetailsById()-- id  {}");
    	Map<Integer, StudentDao> studentData= StudentDetails();
    	
     List<Entry<Integer, StudentDao>> studentbyId = studentData.entrySet().stream().filter(x->x.getKey()==id).collect(Collectors.toList());
     logger.info("--getStudentDetailsById()-- RESPONSE  {}"+studentbyId);
     return studentbyId;
    }

    
    public  Map<Integer, StudentDao> createStudentDetails(StudentDao dao) {
    	logger.info("--createStudentDetails()-- id  {}");
    	Map<Integer, StudentDao> studentData= StudentDetails();
    
    	
    		mymap.put(dao.getStudentId(),dao );
    		
    	
    		return mymap;
    	}
		
    
    
    public  Map<Integer, StudentDao> updateStudentDetails(int id,StudentDao dao) {
    	logger.info("--updateStudentDetails()-- id  {}");
    	Map<Integer, StudentDao> studentData= StudentDetails();
    
    	if(studentData.containsKey(id)) {
    		mymap.put(id, new StudentDao(dao.getStudentId(),dao.getStudentName(),dao.getStudentPhone()));
    		
    	}
    	else
    		{
    		logger.error("--updateStudentDetails()-- Key not available");
    		}
    	logger.info("--updateStudentDetails()-- RESPONSE  {}"+mymap);
    		return mymap;
    	}
    
    
    public  Map<Integer, StudentDao> deleteStudentDetails(int id) {
    	logger.info("--deleteStudentDetails()-- id "+id);
    	Map<Integer, StudentDao> studentData= StudentDetails();
    
    	if(studentData.containsKey(id)) {
    		mymap.remove(id);
    		
    	}
    	else
    		{
    		logger.error("--updateStudentDetails()-- Key not available");
    		}
    	logger.info("--updateStudentDetails()-- RESPONSE  {}"+mymap);
    		return mymap;
    	}
    }
	

