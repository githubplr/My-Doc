package com.swagger.example.entity;

public class Student {

	int studentId;
	String studentName;
	int studentPhone;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int studentId, String studentName, int studentPhone) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentPhone = studentPhone;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getStudentPhone() {
		return studentPhone;
	}

	public void setStudentPhone(int studentPhone) {
		this.studentPhone = studentPhone;
	}

	@Override
	public String toString() {
		return "StudentDao [studentId=" + studentId + ", studentName=" + studentName + ", studentPhone=" + studentPhone
				+ "]";
	}
}
