package com.swagger.example.controller;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.swagger.example.dao.StudentDao;
import com.swagger.example.entity.Student;
import com.swagger.example.services.StudentService;
@RequestMapping("/api")
@RestController
public class StudentController {
	private final static Logger logger= LoggerFactory.getLogger(StudentService.class);
	
	@Autowired
	 StudentService service;
	
	@GetMapping("/studentsDetails")
	public  Map<Integer, StudentDao> getMyStudentDetails() {  
		logger.info("--getMyStudentDetails()-- DATA  {}");
			return service.getStudentDetails();
		}
		
		@GetMapping("/studentsDetails/{id}")
	    public  List<Entry<Integer, StudentDao>> getMyStudentDetailsById(@PathVariable int id) {
			logger.info("--getMyStudentDetailsById()--   {}");
			return service.getStudentDetailsById(id);
	    }

	    @PostMapping("/createsudent")
	    public  Map<Integer, StudentDao> updateMyStudentDetails(@RequestBody Student entity) {
	    	
	    	StudentDao dao= new StudentDao();
	    dao.setStudentId(entity.getStudentId());
	    dao.setStudentName(entity.getStudentName());
	    dao.setStudentPhone(entity.getStudentPhone());
	    Map<Integer, StudentDao> updatestudentdetail=service.createStudentDetails(dao);
	    logger.info("--updateMyStudentDetails()--   {}"+updatestudentdetail);
	    return updatestudentdetail;
	    	}
	    
	    @PutMapping("/updateststudentsdetailsbuyid")
	    public  Map<Integer, StudentDao> createMyStudentDetails(@PathVariable int id,@RequestBody StudentDao dao) {
	    	
	    	StudentDao deo= new StudentDao();
		    deo.setStudentId(deo.getStudentId());
		    deo.setStudentName(deo.getStudentName());
		    deo.setStudentPhone(deo.getStudentPhone());
		    logger.info("--createMyStudentDetails()--   {}"+service.updateStudentDetails(id, dao));
		    return service.updateStudentDetails(id, deo);
	    	}
	    
	    @DeleteMapping("/deletestudentsdetailsbuyid/{id}")
	    public  Map<Integer, StudentDao> deleteMyStudentDetails( @PathVariable int id) {
	    	logger.info("--deleteMyStudentDetails()--   {}"+service.deleteStudentDetails(id));
	    	return service.deleteStudentDetails(id);
	    	
	    	}
	    }


