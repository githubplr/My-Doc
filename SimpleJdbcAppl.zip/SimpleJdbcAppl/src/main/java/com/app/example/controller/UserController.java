package com.app.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.example.repository.UserRepository;

//make this as rest controller

@RestController
@RequestMapping(path="/user")
public class UserController {

	@Autowired
	UserRepository userRepository;
	
	//to test our services is up and running
	@GetMapping
	public String check() {
		return "Hello";
	}
	
	//This method returns List of username
	@GetMapping(path="/getusernames")
	public List<String> getAllUsersNames(){
		
		return userRepository.getAllUsersNames();
	}
}
