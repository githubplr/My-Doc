package com.app.example.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {
	
	//we are adding jdbc template
	//using properties we have configured in application.properties spring
	//automatically create and detect jdbc template  object using the configuration
	@Autowired
	JdbcTemplate jdbcTemplate;

	
	//return the list of users
	public List<String> getAllUsersNames() {
		// TODO Auto-generated method stub
		List<String> userNameList=new ArrayList<>();
		userNameList.addAll(jdbcTemplate.queryForList("select sname from student",String.class));
		return userNameList;
	}

}
