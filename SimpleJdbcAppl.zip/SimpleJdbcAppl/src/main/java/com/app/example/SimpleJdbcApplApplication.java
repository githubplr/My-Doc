package com.app.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleJdbcApplApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleJdbcApplApplication.class, args);
	}

}
